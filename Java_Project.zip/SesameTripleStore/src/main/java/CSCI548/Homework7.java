package CSCI548;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.openrdf.query.BindingSet;
import org.openrdf.query.GraphQueryResult;
import org.openrdf.query.MalformedQueryException;
import org.openrdf.query.QueryEvaluationException;
import org.openrdf.query.QueryLanguage;
import org.openrdf.query.TupleQuery;
import org.openrdf.query.TupleQueryResult;
import org.openrdf.query.TupleQueryResultHandler;
import org.openrdf.query.TupleQueryResultHandlerException;
import org.openrdf.query.Update;
import org.openrdf.query.UpdateExecutionException;
import org.openrdf.query.resultio.sparqljson.SPARQLResultsJSONWriter;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.repository.sparql.SPARQLRepository;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFHandlerException;
import org.openrdf.rio.RDFParseException;
import org.openrdf.sail.inferencer.fc.ForwardChainingRDFSInferencer;
import org.openrdf.sail.memory.MemoryStore;

public class Homework7 
{
	public static void main(String[] args) throws RepositoryException, RDFHandlerException, QueryEvaluationException, TupleQueryResultHandlerException, IOException 
	{
		SPARQLRepository repo = new SPARQLRepository("http://dbpedia.org/sparql");
		repo.initialize();
		
		Repository localRepository = new SailRepository(new ForwardChainingRDFSInferencer(new MemoryStore()));
		localRepository.initialize();

		RepositoryConnection con = repo.getConnection();
		RepositoryConnection localRepoConnection = localRepository.getConnection();
		
		File q4 = new File("C:\\Users\\Pramod P. Setlur\\Google Drive\\USC Subjects\\IIW\\Assignments\\HW7\\q4.txt");
		findAllOrganizations(localRepoConnection,q4);
		
		String constructQueryString = 	"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
										"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"+
										"PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>"+
										"PREFIX dbpprop: <http://dbpedia.org/property/>"+
										"PREFIX dbpedia: <http://dbpedia.org/resource/>"+
										"PREFIX sc: <http://schema.org/>"+
								
										"CONSTRUCT {?privateUniversitiesInCali rdf:type sc:CollegeOrUniversity ."+
										"?privateUniversitiesInCali sc:name ?universityName .} WHERE"+ 
										"{"+
											"{"+
												"?privateUniversitiesInCali rdf:type dbpedia-owl:University ."+
											"}"+
											"{"+
												"?privateUniversitiesInCali <http://dbpedia.org/ontology/type> <http://dbpedia.org/resource/Private_university> ."+
											"}"+
											"UNION"+
											"{"+
												"?privateUniversitiesInCali <http://dbpedia.org/property/type> <http://dbpedia.org/resource/Private_university> ."+
											"}"+
											"{"+
												"?privateUniversitiesInCali dbpedia-owl:state <http://dbpedia.org/resource/California>"+
											"}"+
											"UNION"+
											"{"+
												"?privateUniversitiesInCali dbpprop:state <http://dbpedia.org/resource/California>"+
											"}"+
											"?privateUniversitiesInCali rdfs:label ?universityName ."+
											"FILTER (LANGMATCHES(LANG(?universityName), 'en'))"+
										"}"+
										"GROUP BY ?universityName";
		
		String schemaOrgFilePath = "C:\\Users\\Pramod P. Setlur\\Google Drive\\USC Subjects\\IIW\\Assignments\\HW7\\all.nt";
		File schemaOrgFile = new File(schemaOrgFilePath);
		
		try 
		{
			GraphQueryResult graphResult = con.prepareGraphQuery(QueryLanguage.SPARQL, constructQueryString).evaluate();
			localRepoConnection.add(schemaOrgFile,"",RDFFormat.NTRIPLES);
			while(graphResult.hasNext())
			{
				localRepoConnection.add(graphResult.next());
			}
		} 
		catch (MalformedQueryException e) 
		{
			e.printStackTrace();
		} 
		catch (RDFParseException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		
		File q8 = new File("C:\\Users\\Pramod P. Setlur\\Google Drive\\USC Subjects\\IIW\\Assignments\\HW7\\q8.txt");
		findAllOrganizations(localRepoConnection, q8);
		
		insertIntoLocalRepo(localRepoConnection);
		retreiveAllPersons(localRepoConnection);
		
		con.close();
		localRepoConnection.close();
		
	}

	private static void retreiveAllPersons(RepositoryConnection localRepoConnection) 
	{
		String queryString = 	"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
								"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"+
								"PREFIX schema: <http://schema.org/>"+
									
								"SELECT ?sub WHERE"+
								"{"+
									"?sub a schema:Person"+
								"}";
		try
		{
			TupleQuery tupleQuery = localRepoConnection.prepareTupleQuery(QueryLanguage.SPARQL, queryString);
			File allPersons = new File("C:\\Users\\Pramod P. Setlur\\Google Drive\\USC Subjects\\IIW\\Assignments\\HW7\\q10.txt");
			
			java.io.OutputStream os = new FileOutputStream(allPersons);
			TupleQueryResultHandler writer = new SPARQLResultsJSONWriter(os);
			tupleQuery.evaluate(writer);
		}
		catch (MalformedQueryException e) 
		{
			e.printStackTrace();
		}  
		catch (QueryEvaluationException e) 
		{
			e.printStackTrace();
		} 
		catch (RepositoryException e) 
		{
			e.printStackTrace();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (TupleQueryResultHandlerException e) 
		{
			e.printStackTrace();
		}
		
	}

	private static void insertIntoLocalRepo(RepositoryConnection localRepositoryConnection) 
	{
		String uscUri = "<http://dbpedia.org/page/University_of_Southern_California>";
		String alumniUri = "<http://schema.org/alumni>";
		String nikiasUri = "<http://dbpedia.org/resource/C._L._Max_Nikias>";
		
		String queryString = 	"INSERT DATA"+
								"{"+
									uscUri+alumniUri+nikiasUri+
								"}";
		try 
		{
			Update insertQuery = localRepositoryConnection.prepareUpdate(QueryLanguage.SPARQL, queryString);
			insertQuery.execute();
		} 
		catch (RepositoryException e) 
		{
			e.printStackTrace();
		} 
		catch (MalformedQueryException e) 
		{
			e.printStackTrace();
		} 
		catch (UpdateExecutionException e) 
		{
			e.printStackTrace();
		}
	}

	private static void findAllOrganizations(RepositoryConnection con,File f) 
	{
		String queryString = 	"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"+
								"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"+
								"PREFIX schema: <http://schema.org/>"+

								"SELECT ?sub WHERE"+
								"{"+
									"?sub a schema:Organization"+
								"}";
		
		
		try 
		{
			TupleQuery tupleQuery = con.prepareTupleQuery(QueryLanguage.SPARQL, queryString);
			TupleQueryResult queryResult = tupleQuery.evaluate();
			List<String> bindingName = queryResult.getBindingNames();
			
/*			java.io.OutputStream os = new FileOutputStream(f);
			TupleQueryResultHandler writer = new SPARQLResultsJSONWriter(os);
			tupleQuery.evaluate(writer);*/
			
			FileWriter fw = new FileWriter(f);
			BufferedWriter bw = new BufferedWriter(fw);
			StringBuilder output = new StringBuilder();
			while(queryResult.hasNext())
			{
				BindingSet bindingSet = queryResult.next();
				output.append(bindingSet.getValue(bindingName.get(0))+"\n");
			}
			System.out.println(output.toString());
			bw.write(output.toString());
			 
		} 
		catch (RepositoryException e) 
		{
			e.printStackTrace();
		} 
		catch (MalformedQueryException e) 
		{
			e.printStackTrace();
		} 
		catch (QueryEvaluationException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		
	}

}
